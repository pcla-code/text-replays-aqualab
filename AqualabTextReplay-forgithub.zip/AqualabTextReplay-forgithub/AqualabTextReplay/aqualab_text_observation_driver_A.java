import java.io.*;
import java.util.*;

public class aqualab_text_observation_driver_A{

    //String aqualab_action_data_file_dev1 = "20220522 AQUALAB Raw Log Preprocessing for Text Replays UNIXed No Blanks.csv";
    //String aqualab_action_data_file_dev1 = "20220608 AQUALAB Raw Log Preprocessing for Text Replays SANITIZED.csv";
    String aqualab_action_data_file_dev1 = "20220719v2 AQUALAB Raw Log Preprocessing for Text Replays.csv";

	
	public int goalobs_ = 400;
   
   	public int scrollback = 0;
   
    String outfile_nothi = "observations";
    String repeatfile = "toredo";
    
    public String coder_id = "BOB";
    
    StreamTokenizer st_;
    FileWriter fw_;

    public int totalex = 0;

	public int totallines_ = 0;
	
    public boolean repeatOldFirst = true; // for second coder, etc.

    public void text_observationdriverC(){}

    public StreamTokenizer create_tokenizer(){		      
	
	try{
	    return new StreamTokenizer(new FileReader(aqualab_action_data_file_dev1));
	}
	catch (FileNotFoundException fnfe){
	    fnfe.printStackTrace();
	}
	return null;
    }
    
    public void getLengthOfExisting(){
	try{
	    StreamTokenizer st = new StreamTokenizer(new FileReader(outfile_nothi+coder_id));
	    int tt= StreamTokenizer.TT_NUMBER; totalex = 0;
	    while (tt!= StreamTokenizer.TT_EOF){
		tt = st.nextToken();
		if (tt == StreamTokenizer.TT_EOL)
		    totalex++;
		if ((tt == StreamTokenizer.TT_WORD)&&(st.sval.equals(coder_id)))
		    totalex++;
	    }
	}
	catch (Exception fnfe){
	}
    }

    public int getRepeatClip(int goalclip){
	try{
	    StreamTokenizer st = new StreamTokenizer(new FileReader(repeatfile+coder_id));
	    int tt= StreamTokenizer.TT_NUMBER; int curclipnum = 0; int toret = -1;
	    while (tt!= StreamTokenizer.TT_EOF){

		tt = st.nextToken();
		if (tt == StreamTokenizer.TT_EOL)
		    curclipnum++;
		if ((tt == StreamTokenizer.TT_WORD)&&((st.sval.equals("N"))||(st.sval.equals("G"))))
		    curclipnum++;
		if ((tt == StreamTokenizer.TT_WORD)&&((st.sval.equals("EOL"))))
		    curclipnum++;
		if (curclipnum == goalclip)
		    return toret;
		if (tt == StreamTokenizer.TT_NUMBER)
		    toret = (new Double(st.nval)).intValue();
	    }
	}
	catch (Exception fnfe){
		System.out.println("error in repeatfile");
	    return -1;
	}
	return -1;
    }

    public FileWriter out_tokenizer(){
	try{
	    return new FileWriter(outfile_nothi+coder_id,true);
	}
	catch (Exception fnfe){
	    fnfe.printStackTrace();
	}
	return null;
    }

    public void append_record (String toadd){
	try{
	    fw_ = out_tokenizer();
	    fw_.write(toadd);
	    fw_.flush();
	    fw_.close();
	}
	
	catch (Exception fnfe){
	    fnfe.printStackTrace();
	}
    }
    
    public String getIdentity (){
	return javax.swing.JOptionPane.showInputDialog("Input Coder ID");
    }

    public Object query_cats(String title, String msg){
	Object[] options = { "STRUGGLING", "LOST", "EXPLORING", "DOING OK", "GAMING", "BAD CLIP" };
	return javax.swing.JOptionPane.showOptionDialog(null, msg, title, javax.swing.JOptionPane.DEFAULT_OPTION, javax.swing.JOptionPane.WARNING_MESSAGE, null, options, options[1]);
    }
	
    public Object query_cats_back(String title, String msg){
	Object[] options = { "STRUGGLING", "LOST", "EXPLORING", "DOING OK", "GAMING", "BAD CLIP", "BACK" };
	return javax.swing.JOptionPane.showOptionDialog(null, msg, title, javax.swing.JOptionPane.DEFAULT_OPTION, javax.swing.JOptionPane.WARNING_MESSAGE, null, options, options[1]);
    }

    public Object query_cats_more(String title, String msg){
	Object[] options = { "STRUGGLING", "LOST", "EXPLORING", "DOING OK", "GAMING", "BAD CLIP", "MORE" };
	return javax.swing.JOptionPane.showOptionDialog(null, msg, title, javax.swing.JOptionPane.DEFAULT_OPTION, javax.swing.JOptionPane.WARNING_MESSAGE, null, options, options[1]);
    }
	
    public Object query_cats_back_more(String title, String msg){
	Object[] options = { "STRUGGLING", "LOST", "EXPLORING", "DOING OK", "GAMING", "BAD CLIP", "BACK","MORE" };
	return javax.swing.JOptionPane.showOptionDialog(null, msg, title, javax.swing.JOptionPane.DEFAULT_OPTION, javax.swing.JOptionPane.WARNING_MESSAGE, null, options, options[1]);
    }

    String userid_[] = new String[896194];
	double sessionid_[] = new double[896194];
    double timestamp_[] = new double[896194];
    String jobid_[] = new String[896194];
    String eventid_[] = new String[896194];
    String details1_[] = new String[896194];
    String details2_[] = new String[896194];
    String details3_[] = new String[896194];

	
    // humaninterpretable has headers and prod names, etc etc
    public void readInActions(){
	
	st_ = create_tokenizer();
	st_.whitespaceChars(',', ',');
	st_.wordChars('_', '_');
	st_.wordChars(':', ':');
	
	st_.wordChars(32,32);
	//	fw_ = out_tokenizer();
	boolean quitnow = false;

	int num = -1; String userid = ""; double sessionid = 0.0; 
	String jobid = ""; String eventid = ""; double timestamp = 0.0;
	String details1 = ""; String details2 = ""; String details3 = "";

	
	String curstu = "";

	//collect headers THIS IS 2022 VERSION BUT MIGHT NEED EDITED AFTER STEFAN EDITS PREPROCESSOR
	try{
	st_.nextToken();st_.nextToken();st_.nextToken();st_.nextToken();
	st_.nextToken();st_.nextToken();st_.nextToken();st_.nextToken();
	}catch(Exception e){System.out.println("Header error");}    

	
	while (!quitnow){ 
	    userid = ""; sessionid = 0.0;
	    jobid = ""; eventid = "";
		details1 = ""; details2 = ""; details3 = "";
		timestamp = 0.0; int tt = 0;
		
	    try{
		num+=1; 

		// THIS IS 2022 CODE, PAUSED TO ASK FOR PREPROCESSING MODS
	    tt = st_.nextToken();
		if (tt == StreamTokenizer.TT_EOF)
			throw new Exception("Reached EOF.");
		if (tt != StreamTokenizer.TT_WORD){
			System.out.print("Unexpected userid content line ");
			System.out.println(num);
		}
		else
			userid = st_.sval; 

		tt = st_.nextToken();
		if (tt == StreamTokenizer.TT_EOF)
			throw new Exception("Reached EOF.");
		if (tt != StreamTokenizer.TT_NUMBER){
			System.out.print("Unexpected session content line ");
			System.out.println(num);
		}
		else
			sessionid = st_.nval; 
		
		tt = st_.nextToken();
		if (tt == StreamTokenizer.TT_EOF)
			throw new Exception("Reached EOF.");
		if (tt != StreamTokenizer.TT_NUMBER){
			System.out.print("Unexpected time content line ");
			System.out.println(num);
		}
		else
			timestamp = st_.nval; 
		
		tt = st_.nextToken();
		if (tt == StreamTokenizer.TT_EOF)
			throw new Exception("Reached EOF.");
		if (tt != StreamTokenizer.TT_WORD){
			System.out.print("Unexpected jobid content line ");
			System.out.println(num);
		}
		else
			jobid = st_.sval; 
		
		tt = st_.nextToken();
		if (tt == StreamTokenizer.TT_EOF)
			throw new Exception("Reached EOF.");
		if (tt != StreamTokenizer.TT_WORD){
			System.out.print("Unexpected eventid content line ");
			System.out.println(num);
		}
		else
			eventid = st_.sval; 
		
		tt = st_.nextToken();
		if (tt == StreamTokenizer.TT_EOF)
			throw new Exception("Reached EOF.");
		if (tt != StreamTokenizer.TT_WORD){
			System.out.print("Unexpected details1 content line ");
			System.out.println(num);
		}
		else
			details1 = st_.sval; 
			
		tt = st_.nextToken();
		if (tt == StreamTokenizer.TT_EOF)
			throw new Exception("Reached EOF.");
		if (tt != StreamTokenizer.TT_WORD){
			System.out.println(details1);
			System.out.print("Unexpected details2 content line ");
			System.out.println(num);
		}
		else
			details2 = st_.sval; 
		
		//System.out.println(details2);
		
		tt = st_.nextToken();
		if (tt == StreamTokenizer.TT_EOF)
			throw new Exception("Reached EOF.");
		if (tt != StreamTokenizer.TT_WORD){
			System.out.print("Unexpected details3 content line ");
			System.out.println(num);
			System.out.println(tt);
			System.out.println(st_.nval);
		}
		else
			details3 = st_.sval; 
		
		userid_[num] = userid;
		sessionid_[num] = sessionid;
		timestamp_[num] = timestamp;
		jobid_[num]=jobid;
		eventid_[num]=eventid;
		details1_[num]=details1;
		details2_[num]=details2;
		details3_[num]=details3;
		
		totallines_ = num;
		}
		
	    catch(Exception e){ quitnow=true;}    
	
    }
	}

    public void displayClip (int clipID){
		scrollback = 0;
		displayClip(clipID, clipID, 0.0);
    }

	public int scroll_to_next_task(int clipID){
	
		try{
			while (1==1){
				if (eventid_[clipID].equals("switch_job"))
					return clipID;
				if (eventid_[clipID].equals("complete_task"))
					return clipID++;
				clipID++;
			}
		}
		catch (Exception e){
			while (1==1){
				if (eventid_[clipID].equals("switch_job"))
					return clipID;
				if (eventid_[clipID].equals("complete_task"))
					return clipID++;
				clipID--;
			}
		}
	}
	
	public boolean clipEnd (int clipID, int curnum){
		if (eventid_[curnum].equals("complete_task"))
			return true;
		if (eventid_[curnum].equals("switch_job"))
			return true;
		if (eventid_[curnum].equals("complete_job"))
			return true;
		
		if (jobid_[clipID].equals(jobid_[curnum])) //retaining this because when session changes, job also changes
			return false;
		else	
			return true;
	}
	
    public void displayClip (int clipID, int originalID, double totaltime){
    //clipID= 13334; //for testing short clip
	//clipID = 169005; //for testing student change
	//clipID= 198622;  //for a three-step clip

	double screentotaltime = totaltime;
	//System.out.println(lastID);
	
	clipID++;	
	
	String clip_text = "Job: " + jobid_[clipID] + "\n\n"; String title = "";
	if (details1_[clipID-1].startsWith("task"))
		clip_text = clip_text + details1_[clipID-1] + "\n\n";

	title = "Observation " + (new Integer(totalex+1)).toString() + " for coder " + coder_id + ": Clip " +  (new Integer(clipID+2)).toString() + "\n";	
	int curnum = clipID; int actioncount= 0;
   
	while ((userid_[curnum].equals(userid_[clipID]))&&((actioncount<15)&&(!clipEnd(clipID,curnum)))){
	    actioncount++;
		
		if ((actioncount==0)||(timestamp_[curnum]!=timestamp_[curnum-1]))
			clip_text = clip_text + "Time " + (new Double(totaltime)).toString() + ":\n" ;
		
		//clip_text = clip_text + "Job: " + jobid_[curnum] + "    ";
		
		clip_text = clip_text + "Event: " + eventid_[curnum] + "    ";
		
		clip_text = clip_text + "Details 1: " + details1_[curnum] + "    ";
		clip_text = clip_text + "Details 2: " + details2_[curnum] + "    ";
		clip_text = clip_text + "Details 3: " + details3_[curnum] + "\n";

		if (timestamp_[curnum]!=timestamp_[curnum+1])
			clip_text = clip_text + "\n";

	    totaltime += timestamp_[curnum+1] - timestamp_[curnum];
		
	    curnum++;
		
	    if ((actioncount==15)&&((!clipEnd(clipID,curnum)))&&((!clipEnd(clipID,curnum+1))))
			clip_text = clip_text + "More....";
	
		/**System.out.print(jobid_[clipID]);
		System.out.print(" | ");
		System.out.println(jobid_[curnum]);*/
	}
	
	if ((!jobid_[clipID].equals(jobid_[curnum+1]))&&(jobid_[clipID].equals("no-active-job"))&&(userid_[curnum+1].equals(userid_[clipID]))){
		clip_text = clip_text + "\nNext job: " + jobid_[curnum] + "\n";
	}
		
	Object result_o = null;
	String result_s = "?";
	int result = -1;
	boolean processed = false;

	if (((actioncount == 15)&&((!clipEnd(clipID,curnum)))&&(screentotaltime > 0.0))){
		processed=true;
		result_o = query_cats_back_more(title, clip_text);
		result = ((Integer)result_o).intValue();
		if (result==0)
			result_s = "STRUGGLE";
		if (result==1)
			result_s = "LOST";
		if (result==2)
			result_s = "EXPLORE";
		if (result==3)
			result_s = "OK";
		if (result==4)
			result_s = "GAMING";
		if (result==5)
			result_s = "?";
		if (result<6){
			String toadd = coder_id + " " + (new Integer(originalID+3)).toString() + " " + result_s + "\n";
			append_record(toadd);
		}
		else
			if (result == 6){
				scrollback = 2;
//				System.out.println("set 2");
			}
			else
				displayClip(curnum, originalID, totaltime);
	}
	
	if ((!((actioncount == 15)&&((!clipEnd(clipID,curnum)))))&&(screentotaltime > 0.0)){
		processed=true;
		
		if (sessionid_[curnum]==sessionid_[clipID])
			clip_text = clip_text + "\n" + "Ends with event: " + eventid_[curnum] + " , " + details1_[curnum];
		else
			clip_text = clip_text + "\nSession End";
		
		result_o = query_cats_back(title, clip_text);
		result = ((Integer)result_o).intValue();
		if (result==0)
			result_s = "STRUGGLE";
		if (result==1)
			result_s = "LOST";
		if (result==2)
			result_s = "EXPLORE";
		if (result==3)
			result_s = "OK";
		if (result==4)
			result_s = "GAMING";
		if (result==5)
			result_s = "?";
		if (result<6){
			String toadd = coder_id + " " + (new Integer(originalID+3)).toString() + " " + result_s + "\n";
			append_record(toadd);
		}
		else
			scrollback = 2;
	}
	
	if (((actioncount == 15)&&((!clipEnd(clipID,curnum))))&&(screentotaltime == 0.0)){
		processed = true;
		result_o = query_cats_more(title, clip_text);
		result = ((Integer)result_o).intValue();
		if (result==0)
			result_s = "STRUGGLE";
		if (result==1)
			result_s = "LOST";
		if (result==2)
			result_s = "EXPLORE";
		if (result==3)
			result_s = "OK";
		if (result==4)
			result_s = "GAMING";
		if (result==5)
			result_s = "?";
		if (result<6){
			String toadd = coder_id + " " + (new Integer(originalID+3)).toString() + " " + result_s + "\n";
			append_record(toadd);
		}
		else
			displayClip(curnum, originalID, totaltime);
	}	
	    
	
	if (!processed){
		if (sessionid_[curnum]==sessionid_[clipID])
			clip_text = clip_text + "\n" + "Ends with event: " + eventid_[curnum] + " , " + details1_[curnum];
		else
			clip_text = clip_text + "\nSession End";
		
	    result_o = query_cats(title, clip_text);
		result = ((Integer)result_o).intValue();
		if (result==0)
			result_s = "STRUGGLE";
		if (result==1)
			result_s = "LOST";
		if (result==2)
			result_s = "EXPLORE";
		if (result==3)
			result_s = "OK";
		if (result==4)
			result_s = "GAMING";
		if (result==5)
			result_s = "?";
		if (result<6){
			String toadd = coder_id + " " + (new Integer(originalID+3)).toString() + " " + result_s + "\n";
			append_record(toadd);
		}
	}
	
	//System.out.println("MEEEEEEEEEEEEEEEEEEEEEE");
	//System.out.println(scrollback);
	if (scrollback==2)
		scrollback=1;
	else if (scrollback==1){
		scrollback=0;
//		System.out.println("set 0");
		displayClip(clipID-1, originalID, screentotaltime);	
	}		
//	System.out.println("endfn");
}

    public static void main (String args[]){
	int clipID = -1;

	aqualab_text_observation_driver_A mdd = new aqualab_text_observation_driver_A();
	
	mdd.coder_id = mdd.getIdentity();

	mdd.getLengthOfExisting();
	
	mdd.readInActions();

	
	Random gen = new Random();
	
	while (1==1){
	    if ((mdd.repeatOldFirst)&&(mdd.totalex<mdd.goalobs_))
		clipID = mdd.getRepeatClip(mdd.totalex+1); //need to update with codes Shari selects
	    else
		clipID = gen.nextInt(mdd.totallines_-100); 


	    if (clipID == -1)
		clipID = gen.nextInt(mdd.totallines_-100);       	


		//clipID=14207; //to test scroll to next job
		//clipID=21428; //to test more...
		//clipID=1; //to test session switch end

		clipID = mdd.scroll_to_next_task(clipID);
		
		//clipID= 32892;  //for a longer clip
		

	    mdd.displayClip(clipID);
	    
	    mdd.getLengthOfExisting();
	}
    }
}
